import re
import json

def translate_html(html_path, out_path, translations):
    with open(html_path, 'r', encoding='utf-8') as f:
        html = f.read()

    # Translate text between tags
    def replace_text(match):
        text = match.group(1)
        stripped = text.strip()
        if stripped in translations:
            translated = translations[stripped]
            # preserve leading/trailing whitespace
            return ">" + text.replace(stripped, translated) + "<"
        return match.group(0)

    html = re.sub(r'>([^<]+)<', replace_text, html)

    # Translate specific attributes
    attrs_to_translate = ['alt', 'placeholder', 'title', 'content']
    for attr in attrs_to_translate:
        def replace_attr(match):
            full_match = match.group(0)
            val = match.group(1)
            if val in translations:
                return f'{attr}="{translations[val]}"'
            return full_match
        
        html = re.sub(fr'{attr}="([^"]+)"', replace_attr, html)

    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(html)

if __name__ == "__main__":
    with open("translations.json", "r", encoding="utf-8") as f:
        translations = json.load(f)
    translate_html("index.html", "index_translated.html", translations)
