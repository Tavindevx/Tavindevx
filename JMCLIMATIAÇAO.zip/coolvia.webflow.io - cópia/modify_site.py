import re

# 1. Modify the CSS
with open("coolvia.css", "r", encoding="utf-8") as f:
    css_content = f.read()

# Replace oranges with blue
css_content = css_content.replace("#c53b08", "#0055ff")
css_content = css_content.replace("#d94e1a", "#0077ff")
css_content = css_content.replace("#fff9f7", "#f0f8ff")

with open("coolvia.css", "w", encoding="utf-8") as f:
    f.write(css_content)


# 2. Modify index.html
with open("index.html", "r", encoding="utf-8") as f:
    html_content = f.read()

# Change CSS link
html_content = re.sub(
    r'<link href="https://cdn\.prod\.website-files\.com/[^"]+\.css" rel="stylesheet" type="text/css"[^>]*>',
    '<link href="coolvia.css" rel="stylesheet" type="text/css"/>',
    html_content
)

# Replace logos
logos = [
    "https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a673c7458857690c753fa67_Icon%20(3).svg",
    "https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a673d1f2466a119dcf846f6_Coolvia.svg",
    "https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a648f9fb0c34d7d8bac374a_Logo.svg",
    "https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a6497d6e5a2b98ab9d05e27_Footer-marquee-logo.svg"
]

logo_path = "logo sem fundo vetor branca.png"

for url in logos:
    html_content = html_content.replace(url, logo_path)

with open("index.html", "w", encoding="utf-8") as f:
    f.write(html_content)
