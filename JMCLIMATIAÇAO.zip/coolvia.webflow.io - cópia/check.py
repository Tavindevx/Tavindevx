from bs4 import BeautifulSoup
with open("index.html", "r", encoding="utf-8") as f:
    soup = BeautifulSoup(f, "html.parser")

for tag in ['review', 'team', 'pricing', 'home-blog']:
    if soup.find("section", class_=tag):
        print(f"Warning: {tag} still exists!")
    else:
        print(f"Success: {tag} is removed.")

hero = soup.find("section", class_="hero")
if hero:
    print(f"Hero Title: {hero.find('h1').get_text(strip=True)}")
