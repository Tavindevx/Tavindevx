import re

with open("index.html", "r", encoding="utf-8") as f:
    html = f.read()

# 1. Update logo navbar css
# Instead of max-width: 150px, use max-height: 40px to fit well in a standard navbar
# and make sure it's vertically centered.
old_logo_css = ".nav-brand-logo { max-width: 150px; height: auto !important; object-fit: contain; }"
new_logo_css = ".nav-brand-logo { max-height: 50px !important; width: auto !important; object-fit: contain; display: block; margin: 0 auto; }"
html = html.replace(old_logo_css, new_logo_css)

# 2. Update hero background and text color
# Also update the loading screen background (.page-loader)
old_hero_bg = ".hero { background-color: #0d2859 !important; }"
new_styles = """
.hero { background-color: #f4f6f9 !important; }
.hero h1, .hero p, .hero div { color: #141414 !important; }
.page-loader { background-color: #0d2859 !important; }
"""
html = html.replace(old_hero_bg, new_styles)

# Wait, if .hero div { color: #141414 } is set, it might affect buttons that need white text.
# Let's be more specific.
new_styles_specific = """
.hero { background-color: #f4f6f9 !important; }
.hero h1, .hero .paragraph-p1, .hero .heading-style-h6 { color: #1a1a1a !important; }
.page-loader { background-color: #0055ff !important; }
"""
html = html.replace(new_styles, new_styles_specific)

with open("index.html", "w", encoding="utf-8") as f:
    f.write(html)

