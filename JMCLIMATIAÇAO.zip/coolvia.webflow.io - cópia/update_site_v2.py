import re

with open('index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Title & Meta
content = content.replace(
    '<title>Coolvia - Template de Site Webflow em HTML</title>',
    '<title>JM Climatização - Instalação e Manutenção de Ar Condicionado</title>'
)
content = content.replace(
    'data-wf-domain="coolvia.webflow.io"',
    'data-wf-domain="jmclimatizacao.com.br"'
)
content = content.replace(
    '<meta content="O Coolvia é um template de site de serviços de ar condicionado para reparo, manutenção, instalação, preços, SEO local, avaliações e reservas online fáceis." name="description"/>',
    '<meta content="JM Climatização - Instalação, manutenção preventiva e corretiva e limpeza profissional de ar-condicionado residencial e comercial." name="description"/>'
)
content = content.replace(
    '<meta content="Coolvia - Template de Site Webflow em HTML" property="og:title"/>',
    '<meta content="JM Climatização - Especialistas em Climatização" property="og:title"/>'
)
content = content.replace(
    '<meta content="O Coolvia é um template de site de serviços de ar condicionado para reparo, manutenção, instalação, preços, SEO local, avaliações e reservas online fáceis." property="og:description"/>',
    '<meta content="JM Climatização - Instalação, manutenção preventiva e corretiva e limpeza profissional de ar-condicionado residencial e comercial." property="og:description"/>'
)
content = content.replace(
    '<meta content="Coolvia - Template de Site Webflow em HTML" name="twitter:title"/>',
    '<meta content="JM Climatização - Especialistas em Climatização" name="twitter:title"/>'
)
content = content.replace(
    '<meta content="O Coolvia é um template de site de serviços de ar condicionado para reparo, manutenção, instalação, preços, SEO local, avaliações e reservas online fáceis." name="twitter:description"/>',
    '<meta content="JM Climatização - Instalação, manutenção preventiva e corretiva e limpeza profissional de ar-condicionado residencial e comercial." name="twitter:description"/>'
)

# 2. Favicons -> jmlogo-2.webp
favicon_block_pattern = r'<link href="https://cdn\.prod\.website-files\.com/6a250d796b0a7f4dcbf68bad/6a6edad88bd8a1b7e123ed5f_Coolvia%20favicon%20Light\.png".*?<link href="https://cdn\.prod\.website-files\.com/6a250d796b0a7f4dcbf68bad/6a6edad836ae1f2f57edbf85_Coolvia%20favicon%20Light\.png" rel="icon" sizes="512x512" type="image/png"/>'
new_favicons = '<link rel="icon" href="jmlogo-2.webp" type="image/webp"/><link rel="apple-touch-icon" href="jmlogo-2.webp"/>'
content = re.sub(favicon_block_pattern, new_favicons, content)

# 3. Preloader separate image properties
old_loader = '<div class="page-loader"><div class="page-loader-icon-block"><img alt="JM Climatização" class="page-loader-image" loading="lazy" src="jmlogo-2.webp"/><img alt="Ícone do Ventilador" class="page-loader-fan" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a673c74c022ec941bb21bb4_Vector%20(5).svg"/></div><div class="page-loader-text-block"><div class="page-loader-text-inner"><img alt="JM Climatização" class="page-loader-text" loading="lazy" src="jmlogo-2.webp"/></div></div></div>'
new_loader = '<div class="page-loader"><div class="page-loader-icon-block"><img alt="JM Climatização Logo Esquerda" class="page-loader-image loader-logo-left" id="loader-logo-left" data-loader-side="left" loading="lazy" src="jmlogo-2.webp"/><img alt="Ícone do Ventilador" class="page-loader-fan" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a673c74c022ec941bb21bb4_Vector%20(5).svg"/></div><div class="page-loader-text-block"><div class="page-loader-text-inner"><img alt="JM Climatização Logo Direita" class="page-loader-text loader-logo-right" id="loader-logo-right" data-loader-side="right" loading="lazy" src="jmlogo-2.webp"/></div></div></div>'
if old_loader in content:
    content = content.replace(old_loader, new_loader)
    print("✓ Preloader updated with separate logo properties")
else:
    print("✗ Preloader pattern not found exactly, check snippet")

# 4. Clock animation -> clock-animation-blue.svg
old_clock = '<img alt="" class="process-image" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a6701fa3c2a9bcfdf8dc1ce_Clock-animation%20(1).svg"/>'
new_clock = '<img alt="Processo JM Climatização" class="process-image" loading="lazy" src="clock-animation-blue.svg"/>'
if old_clock in content:
    content = content.replace(old_clock, new_clock)
    print("✓ Clock animation updated to clock-animation-blue.svg")
else:
    print("✗ Clock animation pattern not found")

# 5. Service slider arrows
old_service_left = '<div class="service-slider-left-arrow w-slider-arrow-left"><img alt="Seta para Esquerda" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a658f03bbb23d429f70343c_arrow-left%20(2).svg"/></div>'
new_service_left = '<div class="service-slider-left-arrow w-slider-arrow-left" role="button" tabindex="0" aria-label="slide anterior"><img alt="Seta para Esquerda" loading="lazy" src="arrow-left-blue.svg"/></div>'

old_service_right = '<div class="service-slider-right-arrow w-slider-arrow-right"><img alt="Seta para Direita" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a65ae8fd3c613de06071725_arrow-down-02%20(1).svg"/></div>'
new_service_right = '<div class="service-slider-right-arrow w-slider-arrow-right" role="button" tabindex="0" aria-label="próximo slide"><img alt="Seta para Direita" loading="lazy" src="arrow-right-blue.svg"/></div>'

if old_service_left in content:
    content = content.replace(old_service_left, new_service_left)
    print("✓ Service slider left arrow updated")
else:
    print("✗ Service slider left arrow not found")

if old_service_right in content:
    content = content.replace(old_service_right, new_service_right)
    print("✓ Service slider right arrow updated")
else:
    print("✗ Service slider right arrow not found")

# 6. Marquee section removal
old_marquee_sec = '<section class="add"><div class="container"><div class="add-marquee-contant-wrapper"><div class="add-marquee-inner" style="translate: none; rotate: none; scale: none; transform: translate3d(0%, 0px, 0px);"><span class="add-marquee-text" style="font-size:1.5rem; font-weight:600; color:inherit; padding: 0 2rem;">Somos referência quando o assunto é climatização.</span></div></div></div></section>'
if old_marquee_sec in content:
    content = content.replace(old_marquee_sec, '')
    print("✓ Marquee section completely removed")
else:
    print("✗ Marquee section exact match not found, checking regex")
    content = re.sub(r'<section class="add">.*?</section>', '', content, flags=re.DOTALL)
    print("✓ Marquee section removed via regex")

# 7. Home project slider arrows
old_project_left = '<div class="home-project-slider-left-arrow w-slider-arrow-left"><img alt="Seta para Esquerda" class="hpme-project-slider-arrow" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a658f03bbb23d429f70343c_arrow-left%20(2).svg"/></div>'
new_project_left = '<div class="home-project-slider-left-arrow w-slider-arrow-left" role="button" tabindex="0" aria-label="projeto anterior"><img alt="Seta para Esquerda" class="hpme-project-slider-arrow" loading="lazy" src="arrow-left-blue.svg"/></div>'

old_project_right = '<div class="home-project-slider-right-arrow w-slider-arrow-right"><img alt="Seta para Direita" class="hpme-project-slider-arrow" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a65ae8fd3c613de06071725_arrow-down-02%20(1).svg"/></div>'
new_project_right = '<div class="home-project-slider-right-arrow w-slider-arrow-right" role="button" tabindex="0" aria-label="próximo projeto"><img alt="Seta para Direita" class="hpme-project-slider-arrow" loading="lazy" src="arrow-right-white.svg"/></div>'

if old_project_left in content:
    content = content.replace(old_project_left, new_project_left)
    print("✓ Home project slider left arrow updated")
else:
    print("✗ Home project slider left arrow not found")

if old_project_right in content:
    content = content.replace(old_project_right, new_project_right)
    print("✓ Home project slider right arrow updated")
else:
    print("✗ Home project slider right arrow not found")

# 8. Footer: remove social links top block
old_footer_top = '<div class="footer-top-block"></a><a class="footer-social-link w-inline-block" href="https://www.instagram.com/" target="_blank"><div class="footer-social-link-inner"><div class="button-text-b1">Instagram</div><div class="button-text-b1 footer-nav-link-hover">Instagram</div></div></a><a class="footer-social-link w-inline-block" href="https://x.com/" target="_blank"><div class="footer-social-link-inner"><div class="button-text-b1">X/Twitter</div><div class="button-text-b1 footer-nav-link-hover">X/Twitter</div></div></a><a class="footer-social-link w-inline-block" href="http://linkedin.com/" target="_blank"><div class="footer-social-link-inner"><div class="button-text-b1">LinkedIn</div><div class="button-text-b1 footer-nav-link-hover">LinkedIn</div></div></a></div>'
if old_footer_top in content:
    content = content.replace(old_footer_top, '')
    print("✓ Footer top block (social links) removed")
else:
    print("✗ Footer top block exact match not found, checking regex")
    content = re.sub(r'<div class="footer-top-block">.*?</div></div><div class="footer-nav-link-block">', '<div class="footer-nav-link-block">', content, flags=re.DOTALL)

# Clean up empty footer-content-wrapper if left behind
content = content.replace('<div class="footer-content-wrapper"></div>', '')

# Replace external coolvia.webflow.io links in nav and footer with internal hash navigation
link_replacements = {
    'href="https://coolvia.webflow.io/about"': 'href="#sobre"',
    'href="https://coolvia.webflow.io/service"': 'href="#servicos"',
    'href="https://coolvia.webflow.io/project"': 'href="#projetos"',
    'href="https://coolvia.webflow.io/blog"': 'href="#processo"',
    'href="https://coolvia.webflow.io/contact"': 'href="#contato"',
    'href="https://coolvia.webflow.io/service/ac-repair"': 'href="#servicos"',
    'href="https://coolvia.webflow.io/service/ac-service-and-maintenance"': 'href="#servicos"',
    'href="https://coolvia.webflow.io/service/air-conditioning-installation"': 'href="#servicos"',
    'href="https://coolvia.webflow.io/service/commercial-air-conditioning"': 'href="#servicos"',
    'href="https://coolvia.webflow.io/service/ac-gas-recharge"': 'href="#servicos"',
    'href="https://coolvia.webflow.io/service/ac-problem-diagnosis"': 'href="#servicos"',
}
for old_l, new_l in link_replacements.items():
    content = content.replace(old_l, new_l)

# Add section IDs for smooth navigation
content = content.replace('<section class="service">', '<section class="service" id="servicos">')
content = content.replace('<section class="home-project">', '<section class="home-project" id="projetos">')
content = content.replace('<section class="process">', '<section class="process" id="processo">')
content = content.replace('<section class="cta">', '<section class="cta" id="contato">')
content = content.replace('<section class="trust">', '<section class="trust" id="sobre">')

# 9. Update styles in <style> tag
custom_css = """
/* === JM Climatização Custom Enhancements === */
:root {
  --loader-logo-left: url('jmlogo-2.webp');
  --loader-logo-right: url('jmlogo-2.webp');
}

/* Page Loader: propriedades individuais para imagem de cada lado */
.loader-logo-left {
  /* Propriedade para logo do lado esquerdo */
}
.loader-logo-right {
  /* Propriedade para logo do lado direito */
}

/* Gradiente contínuo Hero -> Seção 2 (Trust) */
.hero {
  background: linear-gradient(180deg, #0050d4 0%, #0068ff 50%, #1a75ff 100%) !important;
}
.trust {
  background: linear-gradient(180deg, #1a75ff 0%, #3e88ff 28%, #78aeff 55%, #bbd8ff 80%, #f4f8ff 94%, #ffffff 100%) !important;
}

/* Título e subtítulo da Seção 2 (Trust) em alto contraste */
.trust-title-text,
.trust-title-block h2,
section.trust h2 {
  color: #ffffff !important;
  text-shadow: 0 2px 10px rgba(0, 30, 90, 0.15) !important;
}
.trust-title-block p {
  color: rgba(255, 255, 255, 0.95) !important;
}

/* Cards da seção Trust destacados sobre o gradiente */
.trust-rated-card,
.trust-covered-card,
.trust-units-card,
.trust-partners-card,
.trust-emergency-card {
  background-color: #ffffff !important;
  box-shadow: 0 12px 36px rgba(0, 35, 120, 0.08) !important;
  border: 1px solid rgba(255, 255, 255, 0.8) !important;
}

/* Setas do slider de serviços em azul #0073ff */
.service-slider-left-arrow,
.service-slider-right-arrow {
  border-color: #0073ff !important;
  background-color: #ffffff !important;
  cursor: pointer !important;
  transition: transform 0.2s, background-color 0.2s, border-color 0.2s !important;
}
.service-slider-left-arrow:hover,
.service-slider-right-arrow:hover {
  background-color: #f0f7ff !important;
  transform: scale(1.05) !important;
}

/* Setas do slider de projetos */
.home-project-slider-left-arrow {
  border: 1.5px solid #0073ff !important;
  background-color: transparent !important;
  cursor: pointer !important;
  transition: transform 0.2s, background-color 0.2s !important;
}
.home-project-slider-left-arrow:hover {
  background-color: rgba(0, 115, 255, 0.08) !important;
  transform: scale(1.05) !important;
}
.home-project-slider-right-arrow {
  background-color: #0073ff !important;
  border: 1.5px solid #0073ff !important;
  cursor: pointer !important;
  transition: transform 0.2s, background-color 0.2s !important;
}
.home-project-slider-right-arrow:hover {
  background-color: #005ce6 !important;
  transform: scale(1.05) !important;
}
.hpme-project-slider-arrow {
  mix-blend-mode: normal !important;
}

/* Footer cinza escuro elegante */
.footer {
  background-color: #18181b !important;
  color: #ffffff !important;
  padding-top: 64px !important;
}
.footer-nav-link-title {
  color: #ffffff !important;
  font-weight: 600 !important;
  letter-spacing: 0.5px !important;
}
.footer-nav-link,
.footer-nav-link .button-text-b1 {
  color: #a1a1aa !important;
  transition: color 0.2s ease !important;
}
.footer-nav-link:hover .button-text-b1 {
  color: #38bdf8 !important;
}
.footer-bottom-block {
  border-top: 1px solid rgba(255, 255, 255, 0.1) !important;
  padding-top: 24px !important;
  margin-top: 48px !important;
}
.footer-copyright-text {
  color: #71717a !important;
  font-size: 0.875rem !important;
}
"""

# Append custom CSS to the last <style> tag
last_style_close = content.rfind('</style>')
if last_style_close != -1:
    content = content[:last_style_close] + '\n' + custom_css + '\n' + content[last_style_close:]
    print("✓ Custom CSS injected into <style> tag")

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(content)

print("✓ Successfully saved updated index.html")
