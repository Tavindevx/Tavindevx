import re

with open('index.html', 'r', encoding='utf-8') as f:
    html = f.read()

original = html

# ─── 1. Footer copyright: "Coolvia" → "JM Climatização" ───────────────────────
html = html.replace(
    '© 2026 Coolvia. Todos os direitos reservados.',
    '© 2026 JM Climatização. Todos os direitos reservados.'
)

# ─── 2. Remove footer-bottom-link-wrapper (Criado por Grabui / Feito com Webflow) ─
html = html.replace(
    '<div class="footer-bottom-link-wrapper">'
    '<div class="footer-copyright-text">Criado por '
    '<a class="footer-bottom-link" href="https://grabui.com/" target="_blank">Grabui</a>'
    '</div>'
    '<div class="footer-copyright-text">Feito com '
    '<a class="footer-bottom-link" href="https://webflow.com/" target="_blank">Webflow</a>'
    '</div></div>',
    ''
)

# ─── 3. Remove coluna Legal do footer ─────────────────────────────────────────
html = html.replace(
    '<div class="footer-nav-link-column">'
    '<div class="footer-nav-link-title">Legal</div>'
    '<div class="footer-nav-links-wrapper">'
    '<a class="footer-nav-link w-inline-block" href="https://coolvia.webflow.io/style-guide">'
    '<div class="footer-nav-link-inner">'
    '<div class="button-text-b1">Guia de estilo</div>'
    '<div class="button-text-b1 footer-nav-link-hover">Guia de estilo</div>'
    '</div></a>'
    '<a class="footer-nav-link w-inline-block" href="https://coolvia.webflow.io/licenses">'
    '<div class="footer-nav-link-inner">'
    '<div class="button-text-b1">Licenças</div>'
    '<div class="button-text-b1 footer-nav-link-hover">Licenças</div>'
    '</div></a>'
    '<a class="footer-nav-link w-inline-block" href="https://coolvia.webflow.io/changelog">'
    '<div class="footer-nav-link-inner">'
    '<div class="button-text-b1">Registro de alterações</div>'
    '<div class="button-text-b1 footer-nav-link-hover">Registro de alterações</div>'
    '</div></a>'
    '</div></div>',
    ''
)

# ─── 4. Remove descrição "A JM Climatização atende..." ───────────────────────
html = html.replace(
    '<div class="container">A JM Climatização atende residências e empresas com serviços de instalação, manutenção e limpeza de ar-condicionado.</div>',
    ''
)

# ─── 5. "See What's Been Delivered Recently" → "Confira nossos serviços realizados" ──
html = html.replace(
    '<h2>See What\'s Been Delivered Recently</h2>',
    '<h2>Confira nossos serviços realizados</h2>'
)

# ─── 6. Substituir marquee de ícones por texto "Somos referência..." ──────────
old_marquee = (
    '<div class="add-marquee-contant-wrapper">'
    '<div class="add-marquee-inner" style="translate: none; rotate: none; scale: none; transform: translate3d(-73.25%, 0px, 0px);">'
    '<img alt="Ícone Controlado" class="add-marquee-icon" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a3a77cff4879105ae860c76_add-icon.svg">'
    '<img alt="Ícone Controlado" class="add-marquee-icon" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a3a77cff4879105ae860c76_add-icon.svg">'
    '<img alt="Ícone Controlado" class="add-marquee-icon" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a3a77cff4879105ae860c76_add-icon.svg">'
    '</div>'
    '<div class="add-marquee-inner" style="translate: none; rotate: none; scale: none; transform: translate3d(-73.25%, 0px, 0px);">'
    '<img alt="Ícone Controlado" class="add-marquee-icon" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a3a77cff4879105ae860c76_add-icon.svg">'
    '<img alt="Ícone Controlado" class="add-marquee-icon" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a3a77cff4879105ae860c76_add-icon.svg">'
    '<img alt="Ícone Controlado" class="add-marquee-icon" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a3a77cff4879105ae860c76_add-icon.svg">'
    '</div>'
    '<div class="add-marquee-inner" style="translate: none; rotate: none; scale: none; transform: translate3d(-73.25%, 0px, 0px);">'
    '<img alt="Ícone Controlado" class="add-marquee-icon" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a3a77cff4879105ae860c76_add-icon.svg">'
    '<img alt="Ícone Controlado" class="add-marquee-icon" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a3a77cff4879105ae860c76_add-icon.svg">'
    '<img alt="Ícone Controlado" class="add-marquee-icon" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a3a77cff4879105ae860c76_add-icon.svg">'
    '</div></div>'
)
new_marquee = '<div class="add-marquee-contant-wrapper"><div class="add-marquee-inner" style="translate: none; rotate: none; scale: none; transform: translate3d(0%, 0px, 0px);"><span class="add-marquee-text" style="font-size:1.5rem; font-weight:600; color:inherit; padding: 0 2rem;">Somos referência quando o assunto é climatização.</span></div></div>'

if old_marquee in html:
    html = html.replace(old_marquee, new_marquee)
    print("✓ Marquee substituído")
else:
    print("✗ Marquee NÃO encontrado — tentando regex…")
    html = re.sub(
        r'<div class="add-marquee-contant-wrapper">.*?</div></div>',
        new_marquee,
        html,
        flags=re.DOTALL
    )

# ─── 7. Remover cta-form-field-block (formulário) e cta-info-block ────────────
#   Substituir bloco do formulário por botão "Converse conosco"
form_block = (
    '<div class="cta-form-field-block">'
    '<div class="form-text-field-wrapper">'
    '<div class="form-text-field-block">'
    '<label class="form-lebel-text" for="Fast-Name">Primeiro Nome</label>'
    '<input class="form-text-field w-input" data-name="Fast Name" id="Fast-Name" maxlength="256" name="Fast-Name" placeholder="Enter first name" type="text">'
    '</div>'
    '<div class="form-text-field-block">'
    '<label class="form-lebel-text" for="Last-Name">Último Nome</label>'
    '<input class="form-text-field w-input" data-name="Last Name" id="Last-Name" maxlength="256" name="Last-Name" placeholder="Enter last name" type="text">'
    '</div></div>'
    '<div class="form-text-field-wrapper">'
    '<div class="form-text-field-block">'
    '<label class="form-lebel-text" for="email">Endereço de E-mail</label>'
    '<input aria-label="Email Address" class="form-text-field w-input" data-name="Email" id="email" maxlength="256" name="Email" placeholder="Enter email address" required="" type="email">'
    '</div>'
    '<div class="form-text-field-block">'
    '<label class="form-lebel-text" for="Phone-Number">Número de Telefone</label>'
    '<input class="form-text-field w-input" data-name="Phone Number" id="Phone-Number" maxlength="256" name="Phone-Number" placeholder="Enter phone number" type="tel">'
    '</div></div>'
    '<div class="form-text-field-block">'
    '<label class="form-lebel-text" for="Massage">Conte-nos Um Pouco Mais</label>'
    '<textarea class="form-text-field text-area w-input" data-name="Massage" id="Massage" maxlength="5000" name="Massage" placeholder="Briefly explain your requirement..."></textarea>'
    '</div></div>'
)

if form_block in html:
    html = html.replace(form_block,
        '<div class="cta-form-field-block" style="display:flex;justify-content:center;padding:2rem 0;">'
        '<a class="cta-whatsapp-btn" href="https://wa.me/55" target="_blank" '
        'style="display:inline-flex;align-items:center;gap:.6rem;background:#25d366;color:#fff;'
        'font-size:1.1rem;font-weight:600;padding:1rem 2.2rem;border-radius:50px;text-decoration:none;'
        'box-shadow:0 4px 18px rgba(37,211,102,.35);transition:transform .2s,box-shadow .2s;">'
        'Converse conosco</a></div>'
    )
    print("✓ Formulário substituído por botão")
else:
    print("✗ Formulário NÃO encontrado — verificar HTML")

info_block = (
    '<div class="cta-info-block">'
    '<div class="cta-link-block">'
    '<div class="cta-copy-icon-block">'
    '<img alt="Copy Icon" loading="lazy" src="https://cdn.prod.website-files.com/6a250d796b0a7f4dcbf68bad/6a43952bc16c54798e5ee339_copy-icon.svg">'
    '</div>'
    '<a class="cta-link" href="mailto:hello@coolvia.com.">hello@coolvia.com.</a>'
    '</div>'
    '<div class="cta-description-block">'
    '<div class="paragraph-p2">Um técnico vai revisar sua solicitação e responder em até 60 minutos em horário comercial.</div>'
    '</div></div>'
)

if info_block in html:
    html = html.replace(info_block, '')
    print("✓ cta-info-block removido")
else:
    print("✗ cta-info-block NÃO encontrado")

# ─── 8. Atualizar perguntas do FAQ ────────────────────────────────────────────
faq_items = [
    # (pergunta_antiga, resposta_antiga, pergunta_nova, resposta_nova)
]

# Buscar padrão do FAQ para entender a estrutura
faq_match = re.search(r'faq|accordion|\.faq-|faq-section', html, re.IGNORECASE)
if faq_match:
    print(f"✓ Estrutura FAQ encontrada em índice {faq_match.start()}")
    context = html[max(0, faq_match.start()-50):faq_match.start()+300]
    print("Contexto:", context[:400])
else:
    print("✗ FAQ não encontrado por regex — buscando accordion...")
    acc_match = re.search(r'accordion', html, re.IGNORECASE)
    if acc_match:
        context = html[max(0, acc_match.start()-50):acc_match.start()+400]
        print("Contexto accordion:", context[:400])

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(html)

changed = sum(1 for a, b in zip(original, html) if a != b)
print(f"\n✓ Arquivo salvo. Diferenças: {len(original)} → {len(html)} chars ({len(html)-len(original):+d})")
