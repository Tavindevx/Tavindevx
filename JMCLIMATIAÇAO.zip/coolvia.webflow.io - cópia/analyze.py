from bs4 import BeautifulSoup

with open("index.html", "r", encoding="utf-8") as f:
    soup = BeautifulSoup(f, "html.parser")

sections = soup.find_all("section")
for s in sections:
    print(f"Section Class: {s.get('class')}")
    # Print h2 titles
    h2s = s.find_all("h2")
    if h2s:
        print(f"  Titles: {[h.get_text(strip=True) for h in h2s]}")

