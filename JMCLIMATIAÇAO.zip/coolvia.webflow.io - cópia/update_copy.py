from bs4 import BeautifulSoup
import re

with open("index.html", "r", encoding="utf-8") as f:
    soup = BeautifulSoup(f, "html.parser")

# Global Fixes: CSS for Logo, Webflow Badge, Orange Hero Image
head = soup.find("head")
style = soup.new_tag("style")
style.string = """
.nav-brand-logo { max-width: 150px; height: auto !important; object-fit: contain; }
.footer-logo { max-width: 150px; height: auto !important; object-fit: contain; }
.w-webflow-badge { display: none !important; }
.hero-image { filter: hue-rotate(190deg); }
"""
head.append(style)

# Remove Webflow badge element just in case
for badge in soup.select('.w-webflow-badge'):
    badge.decompose()

def set_text(element, text):
    if element:
        # Clear existing content
        element.string = ""
        element.append(text)

# 2. Hero Section
hero = soup.find("section", class_="hero")
if hero:
    caption = hero.find("div", class_="hero-caption-block")
    if caption: caption.decompose() # Remove "AC Response • 24/7"
    
    title = hero.find("h1")
    set_text(title, "Seu ambiente climatizado, do jeito que deve ser.")
    
    desc = hero.select_one(".hero-description-block .paragraph-p1")
    set_text(desc, "Instalação, manutenção e limpeza de ar-condicionado com qualidade, segurança e atendimento personalizado.")
    
    data_cards = hero.find("div", class_="hero-data-card-wrapper")
    if data_cards: data_cards.decompose() # Remove stats
    
    btn_pri = hero.select(".button-primary .button-text-b1")
    for btn in btn_pri: set_text(btn, "Falar com a gente no WhatsApp")
    
    btn_sec = hero.select(".button-secondery .button-text-b1")
    for btn in btn_sec: set_text(btn, "Conhecer nossos serviços")

    # update links
    for a in hero.find_all("a"):
        if 'button-primary' in a.get('class', []):
            a['href'] = "https://wa.me/"
        if 'button-secondery' in a.get('class', []):
            a['href'] = "#service"

# 3. Trust Section
trust = soup.find("section", class_="trust")
if trust:
    trust_top = trust.select_one(".trust-top-block")
    if trust_top:
        caption = trust_top.select_one(".section-caption-block")
        if caption: caption.decompose()
        
        title = trust_top.select_one(".trust-title-text")
        set_text(title, "Por que escolher a JM Climatização?")
        
        # Add Subtitle
        sub = soup.new_tag("p")
        sub['style'] = "margin-top: 15px; color: #fff; font-size: 1.1rem;"
        sub.string = "Trabalhamos para entregar um serviço de qualidade, com atenção aos detalhes e foco no conforto do seu ambiente."
        title.insert_after(sub)

    # Benefícios
    cards = trust.select(".trust-cards-wrapper > div")
    bens = [
        ("Serviço de qualidade", "Realizamos cada serviço com cuidado e atenção para garantir o bom funcionamento do seu equipamento."),
        ("Atendimento personalizado", "Entendemos sua necessidade para indicar o serviço mais adequado para o seu ambiente."),
        ("Orçamento transparente", "Você recebe todas as informações sobre o serviço antes da execução."),
        ("Residencial e comercial", "Atendemos diferentes tipos de ambientes, de residências a estabelecimentos comerciais.")
    ]
    
    for i, card in enumerate(cards):
        if i < 4:
            title = card.select_one(".heading-style-h5")
            if title:
                # Remove spans like 4.9 or $20M
                for span in title.find_all("span"): span.decompose()
                set_text(title, bens[i][0])
            desc = card.select_one(".paragraph-p2")
            if desc: set_text(desc, bens[i][1])
            
            # Remove partner logos from card 4
            if i == 3:
                partners = card.select_one(".trust-partners-block")
                if partners: partners.decompose()
        else:
            card.decompose() # Remove the 5th card

    # Also fix the slider versions
    slider_cards = trust.select(".trust-slide")
    for i, slide in enumerate(slider_cards):
        if i < 4:
            card = slide.select_one("div")
            title = card.select_one(".heading-style-h5")
            if title:
                for span in title.find_all("span"): span.decompose()
                set_text(title, bens[i][0])
            desc = card.select_one(".paragraph-p2")
            if desc: set_text(desc, bens[i][1])
            partners = card.select_one(".trust-partners-block")
            if partners: partners.decompose()
        else:
            slide.decompose()

# 4. Service Section
service = soup.find("section", class_="service")
if service:
    title = service.select_one(".service-title-block h2")
    set_text(title, "Nossos Serviços")
    sub = soup.new_tag("p")
    sub['style'] = "margin-top: 15px; color: #5d6c7b;"
    sub.string = "Soluções para manter seu ambiente confortável e seu ar-condicionado funcionando bem."
    title.insert_after(sub)
    
    # We only want 3 services. The HTML has .service-card-block _01, _02, _03, _04, _05
    services_data = [
        ("Instalação de Ar-Condicionado", "Instalação segura e adequada para garantir o bom funcionamento, desempenho e eficiência do seu equipamento."),
        ("Manutenção de Ar-Condicionado", "Manutenção preventiva e corretiva para identificar problemas, melhorar o desempenho e prolongar a vida útil do equipamento."),
        ("Limpeza de Ar-Condicionado", "Higienização do equipamento para melhorar o funcionamento, o conforto e a qualidade do ar no ambiente.")
    ]
    
    blocks = service.select(".service-cards-wrapper > .service-card-block")
    for i, block in enumerate(blocks):
        if i < 3:
            h4 = block.select_one(".heading-style-h4")
            set_text(h4, services_data[i][0])
            
            info_block = block.select_one(".home-service-card-info-block")
            p = soup.new_tag("p")
            p['style'] = "color: #5d6c7b; margin-top: 10px; font-size: 0.9rem;"
            p.string = services_data[i][1]
            info_block.append(p)
            
            a = block.select_one("a.home-service-card")
            if a: a['href'] = "https://wa.me/"
        else:
            block.decompose()
            
    # Remove extra bottom numbers
    nums = service.select(".service-card-bottom-block .service-card-number-block")
    for i, num in enumerate(nums):
        if i < 3:
            p2 = num.select_one(".paragraph-p2")
            set_text(p2, f"0{i+1} - {services_data[i][0]}")
        else:
            num.decompose()
            
    # Remove extra slides in mobile view
    slides = service.select(".service-slide")
    for i, slide in enumerate(slides):
        if i < 3:
            h4 = slide.select_one(".heading-style-h4")
            set_text(h4, services_data[i][0])
            
            info_block = slide.select_one(".home-service-card-info-block")
            p = soup.new_tag("p")
            p['style'] = "color: #5d6c7b; margin-top: 10px; font-size: 0.9rem;"
            p.string = services_data[i][1]
            info_block.append(p)
            
            a = slide.select_one("a.home-service-card")
            if a: a['href'] = "https://wa.me/"
        else:
            slide.decompose()

# 5. Projects Section
projects = soup.find("section", class_="home-project")
if projects:
    title = projects.select_one(".home-project-title-text")
    set_text(title, "Nossos Trabalhos")
    
    # Subtitle is often in .heading-style-h5 inside the sticky part? No, let's find the subtitle.
    # The original was "See What's Been Delivered Recently". Let's look for h5 or just find that text.
    # We will replace all text inside the caption block or sub title.
    for h in projects.find_all("h3"):
        if "Recent" in h.get_text() or "Entregue" in h.get_text():
            set_text(h, "Confira alguns dos serviços realizados pela JM Climatização.")
            
    cards = projects.select(".project-card")
    proj_labels = ["Instalação de ar-condicionado", "Manutenção de equipamento", "Limpeza e higienização", "Instalação residencial"]
    for i, card in enumerate(cards):
        h5 = card.select_one(".heading-style-h5")
        if h5: set_text(h5, proj_labels[i % len(proj_labels)])
        
        # Remove small text descriptions like "Restored within 4 hours"
        small_text = card.select_one(".paragraph-p2")
        if small_text: small_text.decompose()
        
        a = card.find("a")
        if a: a['href'] = "https://wa.me/"

# 6. Process Section
process = soup.find("section", class_="process")
if process:
    title = process.select_one("h2")
    set_text(title, "Como funciona")
    
    sub = process.select_one(".process-top-block .heading-style-h5")
    if sub: set_text(sub, "Do primeiro contato à realização do serviço, tudo simples e transparente.")
    
    steps = process.select(".process-list-item")
    step_data = [
        ("Fale com a gente", "Chame pelo WhatsApp e conte o que você precisa."),
        ("Entendemos sua necessidade", "Avaliamos o ambiente, o equipamento e o serviço necessário."),
        ("Receba seu orçamento", "Apresentamos a melhor solução e combinamos todos os detalhes."),
        ("Serviço realizado", "Nossa equipe realiza o serviço com cuidado e atenção aos detalhes.")
    ]
    for i, step in enumerate(steps):
        if i < 4:
            h5 = step.select_one(".heading-style-h5")
            set_text(h5, step_data[i][0])
            p = step.select_one(".paragraph-p1")
            set_text(p, step_data[i][1])
            
    btn = process.select(".button-primary .button-text-b1")
    for b in btn: set_text(b, "Falar com um especialista")
    
    for a in process.find_all("a", class_="button-primary"):
        a['href'] = "https://wa.me/"

# 7. Area Section
area = soup.find("section", class_="area")
if area:
    title = area.select_one("h2")
    set_text(title, "Atendemos sua região")
    
    # Find subtitle "We Cover These Areas..." or translated "Atendemos Estas Áreas..."
    # Usually in a paragraph or h5
    for p in area.find_all(["p", "h3", "h4", "h5", "div"]):
        if "Brisbane" in p.get_text():
            set_text(p, "A JM Climatização atende residências e empresas com serviços de instalação, manutenção e limpeza de ar-condicionado.")
            break
            
    # Replace Bairros
    items = area.select(".area-card-info-block")
    for i, item in enumerate(items):
        h5 = item.select_one(".heading-style-h5")
        if h5: set_text(h5, f"Bairro {i+1}")
        p = item.select_one(".paragraph-p3")
        if p: p.decompose()

# 8. Reviews
review = soup.find("section", class_="review")
if review: review.decompose()

# 9. Pricing
pricing = soup.find("section", class_="pricing")
if pricing: pricing.decompose()

# 10. CTA (Contact)
cta = soup.find("section", class_="cta")
if cta:
    form = cta.select_one(".form-wrapper")
    if form:
        form.clear() # Remove everything inside the form
        
        # Add new CTA content
        h3 = soup.new_tag("h3")
        h3['class'] = "heading-style-h3"
        h3.string = "Vamos cuidar do seu ar-condicionado?"
        
        p = soup.new_tag("p")
        p['class'] = "paragraph-p1"
        p['style'] = "margin-top: 20px; margin-bottom: 30px; color: #fff;"
        p.string = "Tire suas dúvidas, solicite um orçamento ou agende seu serviço diretamente pelo WhatsApp."
        
        a = soup.new_tag("a")
        a['href'] = "https://wa.me/"
        a['class'] = "button-primary w-inline-block"
        
        div1 = soup.new_tag("div")
        div1['class'] = "button-primary-text-block"
        b1 = soup.new_tag("div")
        b1['class'] = "button-text-b1"
        b1.string = "Falar com a JM Climatização"
        div1.append(b1)
        a.append(div1)
        
        form.append(h3)
        form.append(p)
        form.append(a)
    
    # Remove left side text if any (the conversation clarifies everything...)
    left_content = cta.select_one(".cta-contant-left-block")
    if left_content:
        left_content.clear()
        
        # Move the new CTA to the left side and make it centered/wide
        left_content.append(form)
        form_block = cta.select_one(".cta-form-block")
        if form_block: form_block.decompose()

# 11. Team
team = soup.find("section", class_="team")
if team: team.decompose()

# 12. FAQ
faq = soup.find("section", class_="faq")
if faq:
    q_data = [
        ("Quais serviços a JM Climatização realiza?", "Trabalhamos com instalação, manutenção e limpeza de ar-condicionado para ambientes residenciais e comerciais."),
        ("Como solicito um orçamento?", "É simples. Clique no botão do WhatsApp e fale conosco. Vamos entender sua necessidade e orientar você."),
        ("Vocês atendem residências e empresas?", "Sim. Atendemos diferentes tipos de ambientes, de residências a estabelecimentos comerciais."),
        ("Posso agendar um serviço pelo WhatsApp?", "Sim. Nossa equipe pode orientar você e combinar os detalhes do serviço diretamente pelo WhatsApp.")
    ]
    
    items = faq.select(".faq-accordion-item")
    for i, item in enumerate(items):
        if i < 4:
            q = item.select_one(".faq-accordion-title")
            set_text(q, q_data[i][0])
            a = item.select_one(".faq-accordion-body p")
            if not a: a = item.select_one(".faq-accordion-body div")
            set_text(a, q_data[i][1])
        else:
            item.decompose()
            
    # Final CTA
    final_cta = faq.select_one(".faq-bottom-block")
    if final_cta:
        h5 = final_cta.select_one(".heading-style-h5")
        if h5: set_text(h5, "Ainda ficou com alguma dúvida?")
        p = final_cta.select_one(".paragraph-p2")
        if p: set_text(p, "Fale diretamente com nossa equipe pelo WhatsApp.")
        btn = final_cta.select(".button-primary .button-text-b1")
        for b in btn: set_text(b, "Falar no WhatsApp")
        a = final_cta.select_one("a.button-primary")
        if a: a['href'] = "https://wa.me/"

# 13. Blog
blog = soup.find("section", class_="home-blog")
if blog: blog.decompose()

# 14. Footer
footer = soup.find("section", class_="footer")
if footer:
    # Navigation links
    nav_links = footer.select(".footer-link-list a")
    keep = ["Início", "Serviços", "Trabalhos", "Contato"]
    for link in nav_links:
        if link.get_text(strip=True) not in keep and link.get_text(strip=True) not in ["Home", "Service", "Project", "Contact"]:
            link.decompose()
        elif link.get_text(strip=True) == "Home": set_text(link, "Início")
        elif link.get_text(strip=True) == "Service": set_text(link, "Serviços")
        elif link.get_text(strip=True) == "Project": set_text(link, "Trabalhos")
        elif link.get_text(strip=True) == "Contact": set_text(link, "Contato")
        
    # Legal / Other links
    for h5 in footer.select(".heading-style-h5"):
        if "Legal" in h5.get_text() or "Navigation" in h5.get_text():
            h5.parent.decompose()
            
    # Footer text
    credits = footer.select(".footer-credit-block .paragraph-p3")
    for cr in credits:
        if "Designed" in cr.get_text() or "Powered" in cr.get_text() or "Criado" in cr.get_text() or "Feito" in cr.get_text():
            cr.decompose()
            
    copyright_txt = footer.select_one(".footer-copyright-text-block .paragraph-p3")
    if copyright_txt: set_text(copyright_txt, "© 2026 JM Climatização. Todos os direitos reservados.")
    
    desc = footer.select_one(".footer-description-block p")
    if not desc: desc = footer.select_one(".footer-description-block div")
    if desc: set_text(desc, "Instalação, manutenção e limpeza de ar-condicionado.")
    
    # JM Climatização text in footer
    footer_logo = footer.select_one(".footer-logo")
    if footer_logo:
        # Keep logo, but update alt
        footer_logo['alt'] = "JM Climatização"
        
# Fix all buttons targeting WhatsApp
for a in soup.find_all("a"):
    text = a.get_text(strip=True).lower()
    if any(keyword in text for keyword in ["whatsapp", "orçamento", "especialista", "agendar", "falar com a gente", "falar no"]):
        a['href'] = "https://wa.me/"
    elif 'button-primary' in a.get('class', []) or 'button-secondery' in a.get('class', []):
        if not a.get('href') or a.get('href') == '#':
             a['href'] = "https://wa.me/"

# Write back
with open("index.html", "w", encoding="utf-8") as f:
    f.write(str(soup))
