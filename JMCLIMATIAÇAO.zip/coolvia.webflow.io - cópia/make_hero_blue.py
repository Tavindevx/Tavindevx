import re

with open("index.html", "r", encoding="utf-8") as f:
    html = f.read()

# Add .hero { background-color: #003073 !important; } to the injected style block
new_style_line = ".hero { background-color: #0d2859 !important; }"

# We know we have a <style> block with .nav-brand-logo
html = html.replace(".hero-image { filter: hue-rotate(190deg); }", 
                    ".hero-image { filter: hue-rotate(190deg); }\n" + new_style_line)

with open("index.html", "w", encoding="utf-8") as f:
    f.write(html)
